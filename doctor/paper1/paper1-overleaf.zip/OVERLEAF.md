# Paper I — Overleaf 导入说明

## 上传
1. Overleaf → New Project → Upload Project
2. 选择 `paper1-overleaf.zip`

## 英文稿
- **Main document**: `latex/main.tex`
- **Compiler**: pdfLaTeX

## 中文稿
- **Main document**: `latex/main-zh.tex`
- **Compiler**: XeLaTeX

## 目录结构
```
latex/main.tex          英文入口
latex/main-zh.tex       中文入口
latex/references.bib    参考文献
latex/sections/         英文章节
latex/sections/zh/      中文章节
figures/                插图 PDF
```

图片路径 `\graphicspath{{../figures/}{figures/}}` 已配置，无需修改。
